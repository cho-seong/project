   $(function() {
        //라디오를 버튼모양으로 바꿔주는 jQuery UI
        $("input[type=radio]").checkboxradio({
            icon: false
        });
        //날짜선택을 편리하게 - Date Picker
        $("#birthday").datepicker({
            dateFormat : "yy-mm-dd",
            showOn: "both",
            buttonImage: "./images/pick.jpg",
            buttonImageOnly: true,
        });    
        $('img.ui-datepicker-trigger').css({'position':'relative','top':'11px','width':'33px','marginTop':'-5px'});
    } );
    
    
      function zipcodeFind(){
        new daum.Postcode({
            oncomplete: function(data) {
                //DAUM 우편번호API가 전달해주는 값을 콘솔에 출력
                console.log("zonecode", data.zonecode);
                console.log("address", data.address);
                //회원 가입폼에 적용
                var f = document.registFrm;//<form>태그의 DOM객체를 변수에 저장
                f.zipcode.value = data.zonecode;
                f.address1.value = data.address;
                f.address2.focus();
            }
        }).open();
    }
    
      function registValdidate(form){
    	//아이디 검증	
  		if(form.userid.value ==""){
  			alert("아이디를 입력하세요");
  			form.userid.focus();
  			return false;
  		}
    	//비밀번호 검증
    	if(!form.pass1.value || !form.pass2.value){
    		alert("비밀번호를 입력하세요");
    		return false;
    	}
    	//비밀번호 확인 검증
    	if(form.pass1.value != form.pass2.value){
    		alert("입력한 비밀번호가 일치하지 않습니다.");
    		frm.pass1.value="";
    		frm.pass2.value="";
    		frm.pass1.focus();
    		return false;
    	}
    	//이름 검증
    	if(form.name.value==""){
    		alert("이름을 입력하세요");
    		form.name.focus();
    		return false;
    	}
    	//성별 검증
    	var isGender = false;
    	for(var i=0; i<form.gender.length; i++){
    		if(form.gender[i].checked==true){
    			isGender = true;
    			break;
    		}
    	}
    	if(isGender !=true){
    		alert("성별을 선택해주세요");
    		form.gender[0].focus();
    		return false;
    	}
    	//생년월일 검증
    	if(form.birthday.value==""){
    		alert("생년월일을 입력해주세요");
    		form.birthday.focus();
    		return false;
    	}
    	//주소 검증
    	if(form.zipcode.value==""){
    		alert("주소를 입력해주세요");
    		form.zipcode.focus();
    		return false;
    	}
    	if(form.address1.value =="" || form.address2.value ==""){
    		
    		if(form.address1.value ==""){
    			alert("상세주소를 입력해주세요");
    			form.address1.focus();
        		return false;
    		}
    		else if(form.address2.value==""){
    			alert("상세주소를 입력해주세요");
    			form.address2.focus();
        		return false;
    		}
    		
    	}
    	//이메일 검증 
    	if(form.email1.value =="" || form.email2.value==""){
    		
    		if(form.email1.value==""){
    			alert("이메일을 입력해주세요");
    			form.email1.focus();
    			return false;
    		}
    		else if (form.email2.value==""){
    			alert("이메일을 입력해주세요");
    			form.email2.focus();
    			return false;
    		}
    	}
    	
    	//휴대폰번호 검증
    	if(form.mobile1.selectedIndex ==0){
    		alert("휴대폰번호 앞자리를 입력해주세요");
    		form.mobile1.focus();
    		return false;
    	}
    	if(form.mobile2.value =="" || form.mobile3.value ==""){
    		
    		if(form.mobile2.value==""){
    			alert("휴대폰번호를 입력해주세요");
    			form.mobile2.focus();
        		return false;
    		}
    		else if(form.mobile3.value==""){
    			alert("휴대폰번호를 입력해주세요");
    			form.mobile3.focus();
        		return false;
    		}
    		
    	}
    	//전화번호 검증
    	if(form.tel1.selectedIndex ==0){
    		alert("전화번호 앞자리를 입력해주세요");
    		form.tel1.focus();
    		return false;
    	}
    	if(form.tel2.value=="" || form.tel3.value==""){
    		
    		if(form.tel2.value==""){
    			alert("전화번호를 입력해주세요");
    			form.tel2.focus();
        		return false;
    		}
    		else if (form.tel3.value==""){
    			alert("전화번호를 입력해주세요");
    			form.tel3.focus();
        		return false;
    		}
    		
    	}
    	
    }
    function idCheck(form){
    	alert("아이디 중복체크는 하지않습니다.");
    }
    
    //이메일 입력 => J18FormObject04.html 참조
    function inputEmail(form){
    	
    	if(form.email_domain.value==""){
    		form.email2.readOnly = false;
    		form.email2.value = "";
    		form.email2.focus();
    		
    		
    	}
    	if(!form.email_domain.value==""){
    		form.email2.readOnly = true;
    		form.email2.value = form.email_domain.value;
    		
    	}
    		
    	/* $('select[name=email_domain]').change(function(){
    		
  	  		var value = $('select[name=email_domain] option:selected').val();
    		
  			// 직접입력
  			if(value==""){
  				//직접 입력해야 하기에, 읽기전용 속성은 해제하고, 기존 입력값도 지운다. 
  				$('input[name=email2]').attr('readonly', false);
  				$('input[name=email2]').val('');
  			}
  			
  			else{
  				//선택한 값으로 입력되어야 하기에, 읽기 전용 속성은 활성화 시킨다. 
  				$('input[name=email2]').attr('readonly', true);
  				//select에서 선택한 값을 입력한다.
  				$('input[name=email2]').val(value);
  			}
  		}); */
    	
    }
    
    //커서 위치 옮기기
    function commonFocusMove(obj, charLen, nextObj){
    	
    	if(obj.value.length == charLen){
    		document.getElementsByName(nextObj)[0].focus();
    	}
    	
    	
    }